﻿using System;
using System.Collections.Generic;
using System.Text;

public class Puppy : Dog
{
    public void Weep()
    {
        Console.WriteLine("weeping");
    }
}