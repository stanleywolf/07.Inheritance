﻿using System;

class Program
{
    static void Main(string[] args)
    {
        var dog = new Puppy();
        dog.Eat();
        dog.Bark();
        dog.Weep();
    }
}